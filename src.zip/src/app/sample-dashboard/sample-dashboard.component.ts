import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { PatientDetailsService } from '../patient-details.service';


@Component({
  selector: 'app-sample-dashboard',
  templateUrl: './sample-dashboard.component.html',
  styleUrls: ['./sample-dashboard.component.css']
})
export class SampleDashboardComponent implements OnInit {

  form: FormGroup;
  date = new Date().toLocaleString;
  constructor(private formBuilder: FormBuilder,
    private loginServ: PatientDetailsService,
    private router: Router) {
    
      this.displayStruct = 'searchFields'

    this.form = this.formBuilder.group({
      personalDetails: this.formBuilder.group({
        patientName: ['', Validators.required],
        callerName: ['', Validators.required],
        providerName: ['', Validators.required],
        dob: ['', Validators.required],
        phoneNumber : ['',Validators.required],
        startTime: [this.date],
        endTime: [],
      }),
      medicalDetails: this.formBuilder.group({
        allergies: [],
        meds: [],
        pmh: [],
        fh: [],
        cc: [],
        hpi:[],
        ros: [],
        exam: [],
      }),
      callDetails: this.formBuilder.group({
        startTime: [],
        endTime: [],
      }),
    });
  }


  displayStruct
  searchResults = true


  displayMode() {
    this.displayStruct = 'patreg'
  }
  
  onSubmit() {
    this.router.navigate(['sampledb'])
    console.log(this.form.value)
    //console.log(this.data)
    this.loginServ.patientDetails(this.form.value).subscribe((data) => {
      //this.apiret = data
      console.log(data)
    })

    /*
  submit() {
    console.log('Submission Details', this.form.value);
  }
*/
  }
  ngOnInit(): void {
    //throw new Error("Method not implemented.");
  }

}
