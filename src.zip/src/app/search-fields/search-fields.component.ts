import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormBuilder} from "@angular/forms";

@Component({
  selector: 'app-search-fields',
  templateUrl: './search-fields.component.html',
  styleUrls: ['./search-fields.component.css']
})
export class SearchFieldsComponent implements OnInit {

  searchForm : FormGroup;
  constructor(private formbuilder:FormBuilder) { 

    this.searchForm = this.formbuilder.group({
      nameSearch: [''],
      dobSearch: [''],
      pcpSearch: [''],
      phoneSearch: [''],
    });

    console.log("hey there!")
    console.log(this.searchForm.value)
  }


  
  
  onSubmit() {
    console.log(this.searchForm.value)
  }

  ngOnInit(): void {
  }

}
